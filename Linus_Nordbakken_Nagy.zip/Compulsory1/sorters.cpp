﻿#include <iostream>
#include "sorters.h"


template <typename T>
void swap(T* xp, T* yp) {
	T temp_arrey = *xp;
	*xp = *yp;
	*yp = temp_arrey;
}


template <typename T>
void selectionSort(T arr[], int n) {

	std::cout << "Selection sorting \n" << std::endl;

	// Loops through the array
	for (int i = 0; i < n-1; i++) {
		int minIndex = i;
		
		// Find element of lowest value
		for (int j = i +1; j < n; j++) {
			// Keeps track of current lowest element
			if (arr[j] < arr[minIndex]) {
				minIndex = j;
			}
		}
		// Swaps positions of elements
		swap(&arr[minIndex], &arr[i]);
		//	if (minIndex != i) {
		//	}
	}
}


template <typename T>
void bubbleSort(T* arr, int n) {
	
}


template <typename T>
void mergeSort(T* arr, const int begin, const int end) {
	
}
template <typename T>
void merge(T* arr, const int begin, const int middle, const int end) {
	
}


template <typename T>
void quickSort(T* arr, int begin, int end) {
	
}
template <typename T>
int partition(T* arr, int begin, int end) {

	return 1;
}


template <typename T>
void heapSort(T* arr, int N) {
	
}
template <typename T>
void heapify(T* arr) {
	
}