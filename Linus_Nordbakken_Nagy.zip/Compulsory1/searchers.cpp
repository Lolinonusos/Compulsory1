﻿#include "searchers.h"

template <typename T>
int searchers<T>::linearSearch(T* arr, int N, int x) {

	return 1;
}


template <typename T>
void searchers<T>::binarySearch(int l, int r, int x) {
	
}
