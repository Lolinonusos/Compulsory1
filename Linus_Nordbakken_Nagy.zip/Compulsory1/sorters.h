﻿#pragma once


template<typename T>
void swap(T* xp, T* yp);

template<typename T>
void selectionSort(T arr[], int n);

template<typename T>
void bubbleSort(T* arr, int n);

template<typename T>
void mergeSort(T* arr, const int begin, const int end);
template<typename T>
void merge(T* arr, const int begin, const int middle, const int end);

template<typename T>
void quickSort(T* arr, int begin, int end);
template<typename T>
int partition(T* arr, int begin, int end);

template<typename T>
void heapSort(T* arr, int N);
template<typename T>
void heapify(T* arr);



