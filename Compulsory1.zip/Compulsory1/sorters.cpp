﻿#include "sorters.h"

template <typename T>
void sorters<T>::swap(T* xp, T* yp) {
	
}


template <typename T>
void sorters<T>::selectionSort(T* arr, int n) {
	
}


template <typename T>
void sorters<T>::bubbleSort(T* arr, int n) {
	
}


template <typename T>
void sorters<T>::mergeSort(T* arr, const int begin, const int end) {
	
}
template <typename T>
void sorters<T>::merge(T* arr, const int begin, const int middle, const int end) {
	
}


template <typename T>
void sorters<T>::quickSort(T* arr, int begin, int end) {
	
}
template <typename T>
int sorters<T>::partition(T* arr, int begin, int end) {

	return 1;
}


template <typename T>
void sorters<T>::heapSort(T* arr, int N) {
	
}
template <typename T>
void sorters<T>::heapify(T* arr) {
	
}